Инструкция по использованию данного шаблона:

1. Загрузите шаблон в вашу систему Latex. Например https://www.overleaf.com
2. Разрешается изменять файлы в папке text:   fulltext.tex, appendix.tex, title.tex, references.bib, а так же добавлять и удалять изображения в папке figures. Остальные файлы не разрешается изменять
3. Файл fulltext.tex будет проверяться на антиплагиат, согласно методическим рекомендациям по написанию дипломной работы/проекта. Это основной текст дипломной работы/проекта

Полезные ссылки:
1. https://www.overleaf.com -- Система по работе LaTEX онлайн
2. https://ru.overleaf.com/learn/latex/Learn_LaTeX_in_30_minutes -- Туториал по LaTEX
3. https://mathpix.com/ -- утилита для перевода текста и формул в формат LaTEX на основании распознавания изображения
4. https://detexify.kirelabs.org/classify.html -- Получение латех кода для Символов
5. https://www.grindeq.com/index.php?p=word2latex&lang=en -- Конвертирование файла MS WORD в формат LaTEX. ВНИМАНИЕ!! ДАЛЕКО НЕ ВСЕГДА РАБОТАЕТ КОРРЕКТНО.



Instructions for using this template:

1. Load the template to your Latex system. For example https://www.overleaf.com
2. It is allowed to change files in the 'text' folder: fulltext.tex, appendix.tex, title.tex, references.bib, as well as add and remove images in the 'figures' folder. Other files are not allowed to be modified
3. The file 'fulltext.tex' will be checked for anti-plagiarism, according to the guidelines for writing a diploma work/project. This is the main text of the work/project

Useful links:
1. https://www.overleaf.com -- Online LaTEX system
2. https://en.overleaf.com/learn/latex/Learn_LaTeX_in_30_minutes -- LaTEX Tutorial
3. https://mathpix.com/ -- a utility for translating text and formulas into LaTEX format based on image recognition
4. https://detexify.kirelabs.org/classify.html -- Getting latex code for Symbols
5. https://www.grindeq.com/index.php?p=word2latex&lang=en -- Convert MS WORD file to LaTEX format. ATTENTION!! DOES NOT ALWAYS WORK CORRECTLY. 
